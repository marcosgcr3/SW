<?php 

//Hay que implementar clases articuloTienda y una para el formulario de la compra
//Tambien hay que hacer el objeto articulo para poder mostrarlos bien en la tienda
require_once 'includes/config.php';


$contenido = '';

function miHorario($row){
   //$contenido = buildHorario($row['id_cita'],$row['fecha'], $row['asunto']);
   //return $contenido;
}

