<?php 


require_once 'includes/config.php';
require_once 'includes/vistas/plantillas/usuario.php';

use es\ucm\fdi\aw\usuarios\Usuario;

function listaMec()
{
   
}