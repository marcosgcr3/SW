<footer>
    <p>&copy; 2024 DriveCrafters - Todos los derechos reservados</p>
</footer>