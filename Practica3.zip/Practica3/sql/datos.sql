TRUNCATE TABLE `Usuarios`;
INSERT INTO `Usuarios` (`NIF`, `nombre`, `apellido`, `correo`, `password`, `rol`) VALUES
(7777777, 'Cristiano', 'Ronaldo', 'elBicho@gmail.com', '1234', 'mecanico');
